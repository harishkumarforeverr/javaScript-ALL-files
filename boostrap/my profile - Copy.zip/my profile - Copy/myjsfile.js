
function randomNo(){
    return Math.floor(Math.random() *1000);
}
function randomefunharish(){
    document.getElementById("hoo").style.backgroundColor="rgb("+randomNo()+","+randomNo()+","+randomNo()+")";
}
setInterval(randomefunharish,1000)